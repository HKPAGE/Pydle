#Authors: Henry Page and Ryan Jerovetz
import random
import tkinter
import os

def get_guess_results(guess):
    guess_letter_count = {}
    guess_result = ""
    for i in range(len(guess)):
        guess_letter_count[guess[i]] = guess_letter_count.get(guess[i],0)+1
        if guess[i] == word_of_the_day[i]:
            guess_result += "O"
        elif word_of_the_day.find(guess[i]) != -1:
            if answer_letter_count[guess[i]] < guess_letter_count[guess[i]]:
                guess_result += "X"
            else :
                guess_result += "_"
        else:
            guess_result += "X"
    return guess_result

answer_list = [] 
script_dir = os.path.dirname(os.path.abspath(__file__)) #Get Path of main.py
file_path = os.path.join(script_dir, "wordle-answers-alphabetical.txt") #Append text file of possible playable words to path
answer_file = open(file_path,"r") #Opens the file
for x in answer_file:
    x = x.strip()
    answer_list.append(x)
answer_file.close()

max_num_guesses = 6
current_num_guesses = 1
word_of_the_day = random.choice(answer_list)
answer_letter_count = {}
for i in word_of_the_day:
    answer_letter_count[i] = answer_letter_count.get(i,0)+1

"""window = tk.Tk()
window.title("Wordle")
window.geometry("400x400")
intro_label = tk.Label(window, text = "Welcome to wordle!\n"
"You have six guesses to find the word of the day.\n"
"After you submit each guess, it will tell you how close you are to the correct word.\n"
"X\tThe letter is not in the word\n"
"_\tThe letter is in the word, but in the wrong place.\n"
"O\tThe letter is in the correct place!")
intro_label.pack()"""

print("Welcome to wordle!")
print("You have six guesses to find the word of the day.")
print("The word of the day is five letters long.")
print("After you submit each guess, it will tell you how close you are to the correct word.")
print("X\tThe letter is not in the word.")
print("_\tThe letter is in the word, but in the wrong place.")
print("O\tThe letter is in the correct place!")

while current_num_guesses <= max_num_guesses:
    guess = input("Guess:")

    while len(guess) != 5:
        print("Your guess must be exactly 5 letters long.")
        guess = input("Guess:")
    
    guess = guess.lower()

    if guess == word_of_the_day:
        break

    wordle_results = get_guess_results(guess)

    print("{}\t{}".format(guess, wordle_results))

    current_num_guesses += 1

if current_num_guesses > max_num_guesses:
    print("Better luck next time!")
    print("The word was: {}".format(word_of_the_day))
else:
    print("You won in {} guesses!".format(current_num_guesses))
'''
window.mainloop()'''